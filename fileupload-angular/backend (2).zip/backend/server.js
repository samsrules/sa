let express=require('express');
let bodyParser=require('body-parser');
let sha1=require('sha1');
let cors=require('cors');
let app=express();
let fs=require('fs');
// var session = require('express-session');
// app.use(session({secret: "Shh, its a secret!"}));

app.use(cors());
app.use(bodyParser.json());
//nodemailer
// const nodemailer = require('nodemailer');
// nodemailer.createTestAccount((err, account) => 
// {
//     let transporter = nodemailer.createTransport({
//         host: 'smtp.ethereal.email',
//         port: 587,
//         secure: false, // true for 465, false for other ports
//         auth: {
//             user: account.user, // generated ethereal user
//             pass: account.pass  // generated ethereal password
//         }
//     });
// })
//for upload
var multer = require('multer');
var DIR = './uploads/';

var storage = multer.diskStorage({ 
        destination: function (req, file, cb) {
            cb(null,DIR);
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
            cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1]);
        }
    });
    var upload = multer({ storage: storage}).single('selectFile');
    // app.get('/session', function(req, res)
    // {
    //     if(req.session.page_views)
    //     {
    //        req.session.page_views++;
    //        res.send("You visited this page " + req.session.page_views + " times");
    //     } else 
    //     {
    //        req.session.page_views = 1;
    //        res.send("Welcome to this page for the first time!");
    //     }
    //  });

    //  app.get('/', function(req, res)
    // {
    //     if(req.session.page_views)
    //     {
    //        req.session.page_views++;
    //        res.send("You visited this page " + req.session.page_views + " times");
    //     } else 
    //     {
    //        req.session.page_views = 1;
    //        res.send("Welcome to this page for the first time!");
    //     }
    //  });


    app.post('/uploadImg',function(req,res)
    {
        
         upload(req, res, function (err) 
         {
             fs.mkdir('sumit');
             console.log(req.file)
            let email=req.body.email;
            console.log(email)
            console.log("upload")
        })
   } ) 
// app.post('/regis',function(req,res)
// {
//    var email=req.body.email;
//    var pass=req.body.password;
//    let mailOptions = {
//     from: '"Fred Foo 👻" <foo@example.com>', 
//     to: 'sumit.ducat@gmail.com', 
//     subject: 'Hello ✔', 
//     text: 'Email :'+email+"\n Password :"+pass, 
//     // html: '<b>Hello world?</b>' // html body
    
// };
// transporter.sendMail(mailOptions, (error, info) => 
// {
//     console.log("mail send")
// })
// })
//     app.post('/login',function(req,res)
// {
//     console.log(req.body)
//     email=req.body.email;
//     pass=sha1(req.body.password);
//     pass1=sha1("sumit");
//     console.log(pass)
//     console.log(pass1)
//     if(email==="sumit.ducat@gmail.com" && pass===pass1)
//     {
//         res.json({msg:'Login Success'})
//     }
//     else
//     {
//         res.json({msg:'Invalid Login'})
//     }
// })
// app.post('/regis',function(req,res)
// {
//    console.log(req.files)
// })
// app.get('/',function(req,res)
// {
//    res.send('Front page');
// })
// app.get('/category/:cat?',function(req,res)
// {
//    res.send('Category page'+req.params.cat);
// })
app.listen(6677,function()
{
    console.log("Work on 6677")
})